Meme Generator
==============

### Getting Started

***Host*** = Your pc or laptop
***Guest*** = Vagrant instance 

- Start your vagrant box (the guest): `vagrant up`
- Log into your vagrant box `vagrant ssh`
- Start your "api": `cd /vagrant_data/scripts/ && python api.py`
- Check everything is running by browsing to the following (on the host):
    - localhost:8080   (meme web page)
    - localhost:5050   (api)

## Scripts


#### meme.py

In the scripts folder there is a python script that will generate a meme. It uses the PIL library, and it
doesn't provide a huge amount of functionality, but it will get the job done.

- ***Command:*** `python meme.py -t "If your gonna eat my froot loops" -b "Your gonna pay the consequences" -f ./images -i firestarter.jpg`

```sh
    parser.add_argument('-t', action="store", dest="top", help='The top text in the meme',required=True)
    parser.add_argument('-b', action="store", dest="bottom", help='The Bottom text in the meme.')
    parser.add_argument('-i', action="store", dest="image", help='The image name.')
    parser.add_argument('-f', action="store", dest="folder", help='Folder to write output to.')
```

The functionality of `meme.py`'s meme generation capabilities are limited. Here are things that it does:
- Allows you to create a meme on an existing image, or will create a black canvas 
- Allows you to place text at the top of your meme and optionally at the bottom
- Will save the output image to a specified folder 

What it doesn't do:
- Doesn't allow for easy font size adjusting.
- Doesn't auto wrap text.
- Doesn't allow for configurable input folder. 

#### api.py

```
"GET": [
[
"/meme_generator/v1.0/grab_image",
"grab_image"
],
[
"/meme_generator/v1.0/find_image",
"find_image"
],
[
"/meme_generator/v1.0/site_map",
"site_map"
],
[
"/",
"index"
]
],
"POST": [
[
"/meme_generator/v1.0/generate_image",
"generate_image"
]
]
```