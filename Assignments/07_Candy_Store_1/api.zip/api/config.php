<?php

$auth = [
    'user' => 'class_user',
    'password' => 'horsedonkeyblanketbattery',
    'host' => 'localhost',
    'db' => '4443-ip'
];

$secret_key = "MaC8hv9mvKXWFR+cVuZiUcZ4oJqDhs6LYrTuty94cVA=";