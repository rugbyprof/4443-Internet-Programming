<?php

$servername = "localhost";
$username = "ufo";
$password = "password";
$dbname = "ufo";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "
CREATE TABLE `ufo_sightings` (
    `id` int(11) NOT NULL,
    `datetime` int(15) NOT NULL,
    `city` varchar(64) NOT NULL,
    `state` varchar(64) NOT NULL,
    `country` varchar(64) NOT NULL,
    `shape` varchar(64) NOT NULL,
    `duration_sec` int(7) NOT NULL,
    `duration_hm` varchar(64) NOT NULL,
    `comments` text NOT NULL,
    `date_posted` int(15) NOT NULL,
    `latitude` float(14,6) NOT NULL,
    `longitude` float(14,6) NOT NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=latin1;";

// if ($conn->query($sql) === TRUE) {

//     echo "Table created...";

// } else {
//     echo "Error: " . $sql . "<br>" . $conn->error;
// }

$csv = array_map('str_getcsv', file('ufo_sightings.csv'));

$conn->query("TRUNCATE ufo_sightings");
$errors = [];
$inserted = 0;
for($i=1;$i<sizeof($csv);$i++){
    $csv[$i][0] = (int)strtotime ($csv[$i][0]);
    $csv[$i][8] = (int)strtotime ($csv[$i][8]);
    $csv[$i][9] = (float)$csv[$i][9];
    $csv[$i][10] = (float)$csv[$i][10];
    $d = $csv[$i];
    $sql = "INSERT INTO ufo_sightings VALUES ('{$i}','{$d[0]}', '{$d[1]}', '{$d[2]}', '{$d[3]}', '{$d[4]}', '{$d[5]}', '{$d[6]}', '{$d[7]}', '{$d[8]}', '{$d[9]}', '{$d[10]}')";
    

    if ($conn->query($sql) === TRUE) {
        $inserted++;
        if($i % 50 == 0){
            echo "{$inserted} records inserted\n";
        }
    } else {
        echo "Error: " . $sql . "\n" . $conn->error."\n";
        $errors[] = $sql;
    }
}

print_r($errors);


