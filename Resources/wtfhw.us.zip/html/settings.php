<?php

return [
    'error_reporting' => 1,
    'site_title' => 'Tin Foil Hat',
    'time_zone' => "America/Chicago",
    'base_url' => '',   
    'mysql' => [
        'dbname' => 'wtfhw.us',
        'pass' => 'password',
        'host' => 'localhost',
        'user' => 'wtfhw.us'
    ],
    'mail'=>[
        'host'=>"smtp.gmail.com",
        'port'=>587,
        'secure'=>'tls',
        'username'=>'wtfhw.us@gmail.com',
        'password'=>'password',
        'from'=>'wtfhw.us@gmail.com'
    ],
    'slim'=> [
        'displayErrorDetails' => true,
        'mongo' => [
            'dbname' => 'wtfhw',
        ],
    ],
];



