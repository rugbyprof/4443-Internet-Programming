<!DOCTYPE html>
<html lang="en">

<?php
    $config = include('settings.php');
    $base = $config['base_url'];
?>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- <link rel="icon" href="<?php echo"{$base}/favicon.ico?v=2"; ?>"> -->
    <link rel="apple-touch-icon" sizes="57x57" href="<?php echo"{$base}"?>/favicon/apple-icon-57x57.png?v=2">
    <link rel="apple-touch-icon" sizes="60x60" href="<?php echo"{$base}"?>/favicon/apple-icon-60x60.png?v=2">
    <link rel="apple-touch-icon" sizes="72x72" href="<?php echo"{$base}"?>/favicon/apple-icon-72x72.png?v=2">
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo"{$base}"?>/favicon/apple-icon-76x76.png?v=2">
    <link rel="apple-touch-icon" sizes="114x114" href="<?php echo"{$base}"?>/favicon/apple-icon-114x114.png?v=2">
    <link rel="apple-touch-icon" sizes="120x120" href="<?php echo"{$base}"?>/favicon/apple-icon-120x120.png?v=2">
    <link rel="apple-touch-icon" sizes="144x144" href="<?php echo"{$base}"?>/favicon/apple-icon-144x144.png?v=2">
    <link rel="apple-touch-icon" sizes="152x152" href="<?php echo"{$base}"?>/favicon/apple-icon-152x152.png?v=2">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo"{$base}"?>/favicon/apple-icon-180x180.png?v=2">
    <link rel="icon" type="image/png" sizes="192x192"  href="<?php echo"{$base}"?>/favicon/android-icon-192x192.png?v=2">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo"{$base}"?>/favicon/favicon-32x32.png?v=2">
    <link rel="icon" type="image/png" sizes="96x96" href="<?php echo"{$base}"?>/favicon/favicon-96x96.png?v=2">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo"{$base}"?>/favicon/favicon-16x16.png?v=2">
    <link rel="manifest" href="<?php echo"{$base}"?>/favicon/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="<?php echo"{$base}"?>/favicon/ms-icon-144x144.png?v=2">
    <meta name="theme-color" content="#ffffff">

    <title><?php echo $config['site_title']; ?></title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo $base?>/css/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="<?php echo $base?>/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?php echo $base?>/css/navbar.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="<?php echo $base?>/js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <!-- CSS to style the file input field as button and adjust the Bootstrap progress bars -->
    <link rel="stylesheet" href="<?php echo $base?>/css/jquery.fileupload.css">
</head>
<body>
    <div class="container">
