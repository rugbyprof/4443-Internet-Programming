<?php
include $page_parts['header'];
include $page_parts['navigation'];
?>

        <!-- Main component for a primary marketing message or call to action -->
        <div class="jumbotron" style="text-align:center;padding-top:-30px;">
            <h1 style="padding-top:-20px;margin-top:-20px;">Where's The Ufo's</h1>
            <div id="map" style="height:600px"></div>
        </div>

<?php
include $page_parts['core_scripts'];
?>

    <script>

      // This example adds a marker to indicate the position of Bondi Beach in Sydney,
      // Australia.
      function initMap() {
        var map, heatmap;
        $.get("https://wtfhw.us/ufos")
            .done(function(data) {
                let markers = [];
                let heat = [];
                console.log( data );

                map = new google.maps.Map(document.getElementById('map'), {
                    zoom: 2,
                    center: { lat: 0, lng: -178 }
                });

                for (let i = 0; i < data.length; i++) {
                    if(data[i].latitude < -89 || data[i].latitude > 89 || data[i].longitude < -178 || data[i].longitude > 178){
                        console.log("out of bounds");
                        continue;
                    } 
                    var myLatLng = { lat: data[i].latitude, lng: data[i].longitude };
                    heat.push(new google.maps.LatLng(data[i].latitude, data[i].longitude));
                    // markers.push(new google.maps.Marker({
                    //     position: myLatLng,
                    //     map: map,
                    //     title: ''
                    // }));
                }

                heatmap = new google.maps.visualization.HeatmapLayer({
                    data: heat,
                    map: map
                });
                console.log(heat);
                console.log(heat[0].lat(),heat[0].lng());
            });

    }

    function toggleHeatmap() {
        heatmap.setMap(heatmap.getMap() ? null : map);
    }

    function changeGradient() {
        var gradient = [
            'rgba(0, 255, 255, 0)',
            'rgba(0, 255, 255, 1)',
            'rgba(0, 191, 255, 1)',
            'rgba(0, 127, 255, 1)',
            'rgba(0, 63, 255, 1)',
            'rgba(0, 0, 255, 1)',
            'rgba(0, 0, 223, 1)',
            'rgba(0, 0, 191, 1)',
            'rgba(0, 0, 159, 1)',
            'rgba(0, 0, 127, 1)',
            'rgba(63, 0, 91, 1)',
            'rgba(127, 0, 63, 1)',
            'rgba(191, 0, 31, 1)',
            'rgba(255, 0, 0, 1)'
        ]
        heatmap.set('gradient', heatmap.get('gradient') ? null : gradient);
    }

    function changeRadius() {
        heatmap.set('radius', heatmap.get('radius') ? null : 200);
    }

    function changeOpacity() {
        heatmap.set('opacity', heatmap.get('opacity') ? null : 0.2);
    }

    </script>
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCjhJnzIbX74ygBv7AlCCFBuq4Ipu4N82c&callback=initMap&libraries=visualization">
    </script>
<?php
include $page_parts['footer'];
?>