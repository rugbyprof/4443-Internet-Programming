<?php
    include($page_parts['header']);
    include($page_parts['navigation']);
?>

    <!-- Main component for a primary marketing message or call to action -->
    <div class="jumbotron">
        <h1>Registration</h1>

        <div class="login-panel panel panel-default" style="margin-left:30%;margin-right:30%">
            <div class="panel-heading">
                <h3 class="panel-title">Sign In</h3>
            </div>
            <div class="panel-body">
                <form role="form" id="login">
                    <fieldset>
                        <div class="form-group">
                            Email: <input class="form-control" placeholder="E-mail" id="email" type="email" autofocus="">
                        </div>
                        <div class="form-group">
                            Password: <input class="form-control" placeholder="Password" id="pwd" type="password" value="">
                        </div>
                        <div class="form-group">
                            Username: <input class="form-control" placeholder="Username" id="username" type="text" value=""> 
                        </div>
                        <!-- Change this to a button or input when using this as a form -->
                        <a href="javascript:;" class="btn btn-sm btn-success" id="registerbutt">Register</a>
                    </fieldset>
                </form>
            </div>
        </div>
    </div>

<?php
    include($page_parts['core_scripts']);
?>

<script src="<?php echo $base?>/js/main.js"></script>

<script>
    $('#registerbutt').click(function() {
        console.log("clicked");
        data = {
            email: $('#email').val(),
            pwd: $('#pwd').val(),
            username: $('#username').val()
        }
        console.log(data);
        $.post( 'https://wtfhw.us/register', data)
        .done(function( data ) {
            //Need to check if it was successful before really doing this...
            window.location = 'https://wtfhw.us/home';
        });
    });
</script>


<?php
    include($page_parts['footer']);
?>