      // This example adds a marker to indicate the position of Bondi Beach in Sydney,
      // Australia.
      function initMap() {
          var map = new google.maps.Map(document.getElementById('map'), {
              zoom: 2,
              center: { lat: 0, lng: -178 }
          });

          var image = 'https://developers.google.com/maps/documentation/javascript/examples/full/images/beachflag.png';
          var beachMarker = new google.maps.Marker({
              position: { lat: -33.890, lng: 151.274 },
              map: map,
              icon: image
          });

          heatmap = new google.maps.visualization.HeatmapLayer({
              data: getPoints(),
              map: map
          });

          function toggleHeatmap() {
              heatmap.setMap(heatmap.getMap() ? null : map);
          }

          function changeGradient() {
              var gradient = [
                  'rgba(0, 255, 255, 0)',
                  'rgba(0, 255, 255, 1)',
                  'rgba(0, 191, 255, 1)',
                  'rgba(0, 127, 255, 1)',
                  'rgba(0, 63, 255, 1)',
                  'rgba(0, 0, 255, 1)',
                  'rgba(0, 0, 223, 1)',
                  'rgba(0, 0, 191, 1)',
                  'rgba(0, 0, 159, 1)',
                  'rgba(0, 0, 127, 1)',
                  'rgba(63, 0, 91, 1)',
                  'rgba(127, 0, 63, 1)',
                  'rgba(191, 0, 31, 1)',
                  'rgba(255, 0, 0, 1)'
              ]
              heatmap.set('gradient', heatmap.get('gradient') ? null : gradient);
          }

          function changeRadius() {
              heatmap.set('radius', heatmap.get('radius') ? null : 20);
          }

          function changeOpacity() {
              heatmap.set('opacity', heatmap.get('opacity') ? null : 0.2);
          }

          get_markers(1000, 0, map);
      }

      function get_markers(number, offset, map) {

          $.get("https://griffincomplaints.xyz/generic/ufos?number=" + number + "&offset=" + offset)
              .done(function(data) {
                  let markers = [];
                  //console.log( data );
                  for (let i = 0; i < data.length; i++) {
                      var myLatLng = { lat: data[i].latitude, lng: data[i].longitude };
                      console.log(data[i]);
                      markers.push(new google.maps.Marker({
                          position: myLatLng,
                          map: map,
                          title: ''
                      }));
                  }

              });
      }