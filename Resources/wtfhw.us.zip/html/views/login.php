<?php
include $page_parts['header'];
include $page_parts['navigation'];
?>

    <!-- Main component for a primary marketing message or call to action -->
    <div class="jumbotron">
        <h1>Login</h1>

        <div class="login-panel panel panel-default" style="margin-left:30%;margin-right:30%">
            <div class="panel-heading">
                <h3 class="panel-title">Sign In</h3>
            </div>
            <div class="panel-body">
                <form role="form" id="login">
                    <fieldset>
                        <div class="form-group">
                            <input class="form-control" placeholder="E-mail" id="email" type="email" autofocus="">
                        </div>
                        <div class="form-group">
                            <input class="form-control" placeholder="Password" id="password" type="password" value="">
                        </div>
                        <div class="checkbox">
                            <label>
                                        <input name="remember" type="checkbox" value="Remember Me">Remember Me
                                    </label>
                        </div>
                        <!-- Change this to a button or input when using this as a form -->
                        <a href="javascript:;" class="btn btn-sm btn-success" id="loginbutt">Login</a>
                    </fieldset>
                </form>
            </div>
        </div>
    </div>

<?php
include $page_parts['core_scripts'];
?>
<script>
$('#loginbutt').click(function(e){
    e.preventDefault();
    let data = {
        email: $('#email').val(),
        password: $('#password').val()  
    }
    $.post("https://wtfhw.us/login",data)
    .done(function(data) {
        console.log(data['success']);
        if(data['success']===true){
            console.log(data);
            window.location = 'https://wtfhw.us/home';
        }else{
            alert(data);
        }
    });
});
</script>
<?php
include $page_parts['footer'];
?>