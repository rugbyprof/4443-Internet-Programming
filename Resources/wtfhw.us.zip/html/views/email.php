<?php
    include($page_parts['header']);
    include($page_parts['navigation']);
?>

    <!-- Main component for a primary marketing message or call to action -->
    <div class="jumbotron">
        <h1>Email</h1>

        <div class="login-panel panel panel-default" style="margin-left:30%;margin-right:30%">
            <div class="panel-heading">
                <h3 class="panel-title">Email </h3>
            </div>
            <div class="panel-body">
                <form role="form" id="email-form">
                    <fieldset>
                    <div class="form-group">
                            <input class="form-control" placeholder="E-mail" name="email" type="email" autofocus="" id="email_address">
                        </div>
                        <div class="form-group">
                            <input class="form-control" placeholder="Subject" name="subject" type="text" autofocus="" id="subject">
                        </div>
                        <div class="form-group">
                            <textarea name="message" id="message" placeholder="Write a message..." ></textarea>
                        </div>
                        <!-- Change this to a button or input when using this as a form -->
                        <a href="javascript:;" class="btn btn-sm btn-success" id="sendbutt">Send</a>
                    </fieldset>
                </form>
            </div>
        </div>
    </div>

<?php
    include($page_parts['core_scripts']);
?>

<script>
    $('#sendbutt').click(function() {
        console.log("clicked");
        data = {
            email: $('#email_address').val(),
            subject: $('#subject').val(),
            message: $('#message').val()

        }
        console.log(data);
        $.post( 'https://wtfhw.us/email', data)
        .done(function( data ) {
            alert( "Data Loaded: " + data );
        });
    });
</script>

<?php
    include($page_parts['footer']);
?>
