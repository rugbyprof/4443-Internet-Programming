<?php
include($page_parts['header']);
include($page_parts['navigation']);
?>

echo"<h1>Hello</h1>";
print_r($this);
print_r($args);

<?php
    include($page_parts['core_scripts']);
    include($page_parts['footer']);
?>