        
        <!-- Static navbar -->
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand" href="<?php echo $base?>/home"><?php echo $config['site_title']?></a>
                </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <?php
                        foreach($menu_array[1] as $item){
                            echo"<li><a href='{$config['base_url']}/{$item['link']}'>{$item['label']}</a></li>";
                        }
                        ?>
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <?php
                        if($_SESSION['auth_logged_in']){
                            foreach($menu_array[2] as $item){
                                echo"<li><a href='{$config['base_url']}/{$item['link']}'>{$item['label']}</a></li>";
                            }
                        }
                        ?>
                    </ul>
                </div>
                <!--/.nav-collapse -->
            </div>
            <!--/.container-fluid -->
        </nav>