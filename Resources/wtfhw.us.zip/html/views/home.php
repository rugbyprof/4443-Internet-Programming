<?php
    include($page_parts['header']);
    include($page_parts['navigation']);
?>

        <!-- Main component for a primary marketing message or call to action -->
        <div class="jumbotron" style="text-align:center">
            <h1>Where's The Ufo's??</h1>

            <img src="./images/ufo_logo_1000.png" style="width:600px">
        </div>

<?php
    include($page_parts['core_scripts']);
    include($page_parts['footer']);
?>