<?php
    include($page_parts['header']);
    include($page_parts['navigation']);
?>

        <!-- Main component for a primary marketing message or call to action -->

        <div class="jumbotron">
            <h1>File Upload</h1>
            <br>
            <!-- The fileinput-button span is used to style the file input field as button -->
            <span class="btn btn-success fileinput-button">
            <i class="glyphicon glyphicon-plus"></i>
            <span>Select files...</span>
            <!-- The file input field used as target for the file upload widget -->
            <input id="fileupload" type="file" name="files[]" multiple>
            </span>
            <br>
            <br>
            <!-- The global progress bar -->
            <div id="progress" class="progress">
                <div class="progress-bar progress-bar-success"></div>
            </div>
            <!-- The container for the uploaded files -->
            <div id="files" class="files"></div>
            <br>
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">Uploaded Files</h3>
                </div>
                <div class="panel-body">
                    <ul id="uploaded_files">

                    </ul>
                </div>
            </div>
        </div>

<?php
    include($page_parts['core_scripts']);
?>

<script>
    /*jslint unparam: true */
    /*global window, $ */
    $(function() {
        'use strict';
        // Change this to the location of your server-side upload handler:
        var url = 'https://wtfhw.us/upload';
        $('#fileupload').fileupload({
                url: url,
                dataType: 'json',
                done: function(e, data) {
                    console.log(data);
                    $.each(data.result.filenames, function(index, file) {
                        $('#uploaded_files').append("<li><a href='https://wtfhw.us/file_uploads/" + file + "'>" + file + "</a></li>");
                    });
                },
                progressall: function(e, data) {
                    var progress = parseInt(data.loaded / data.total * 100, 10);
                    $('#progress .progress-bar').css(
                        'width',
                        progress + '%'
                    );
                }
            }).prop('disabled', !$.support.fileInput)
            .parent().addClass($.support.fileInput ? undefined : 'disabled');
    });
</script>

<?php
    include($page_parts['footer']);
?>
