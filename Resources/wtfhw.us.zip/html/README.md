### Domain Name

Go buy a domain name

### Install Letsencrypt
https://www.digitalocean.com/community/tutorials/how-to-secure-apache-with-let-s-encrypt-on-ubuntu-16-04

### Mail

#### Postfix Mail Server
- https://www.digitalocean.com/community/tutorials/how-to-install-and-configure-postfix-as-a-send-only-smtp-server-on-ubuntu-16-04

#### Use Gmail instead
- https://github.com/PHPMailer/PHPMailer/blob/master/examples/gmail.phps


### Create your "App"

- It's kindof a thing to name the main file running your site `app` or `app.php` in our case. 
- The `app` file is what runs your site. It returns views based on requests.
- The `api` is where you get data from. 
- We can combine both into `app.php` which will then turn it into a big controller connecting views and models.
- One problem with using `app` as the main file is that most servers are looking for `index`. We can fix that by configuring your server to look for `app` instead, OR we can use "Url Rewriting" to handle this issue (discussed in next section).
- Remember, your app contains stuff like below (+ a lot more), dishing out views and grabbing data

```php
// GET /////////////////////////////////////////////////////////////////////////////////////
$app->get("/", "base");
$app->get("/example", "example_handler");
$app->get("/login", \ViewController::class . ":login_view");
$app->get("/email", \ViewController::class . ":email_view");
$app->get("/upload", \ViewController::class . ":file_upload_view");
$app->get('/home', \ViewController::class . ":home_view");
$app->get('/profile_page[/{id}]', \ViewController::class . ":profile_view");
$app->get("/register", \ViewController::class . ":register_view");
$app->get("/ufo", \ViewController::class . ":ufo_view");
$app->get("/ufos", "get_ufos");
$app->get("/confirm_email", "confirm_email");

// POST /////////////////////////////////////////////////////////////////////////////////////
$app->post("/register", "register_user");
$app->post("/example", "example_handler");
$app->post("/email", "send_email");
$app->post("/upload", "uploadImage");
```

### Redirect All Requests to App

- Install `mod_rewrite` an apache module to rewrite urls.
- The command `a2enmod mod_rewrite` will do this.
- Then re-start your server: `service apache2 restart` or `/etc/init.d/apache2 restart`
- Now add an `.htaccess` file to your folder to allow cleaner urls:
    - Typing `https://wtfhw.us/` redirects to `https://wtfhw.us/app.php`
    - Typing `https://wtfhw.us/home` redirects to `https://wtfhw.us/app.php/home`
- Basically routing every request to your `app`.
- Example file:


```
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteRule ^ app.php [QSA,L]
```


### Composer Requirements

composer require slim/slim "^3.0"
composer require slim/php-view
composer require projek-xyz/slim-monolog --prefer-dist
composer config "platform.ext-mongo" "1.6.16" && composer require alcaeus/mongo-php-adapter
composer require delight-im/auth
composer require phpmailer/phpmailer
composer require slim/pdo

Creates a `composer.json` file similar to:

```json
{
    "require": {
        "slim/slim": "^3.0",
        "slim/php-view": "^2.2",
        "alcaeus/mongo-php-adapter": "^1.1",
        "twbs/bootstrap": "^3.3",
        "components/jquery": "^3.2",
        "slim/pdo": "^1.10",
        "delight-im/auth": "^7.2",
        "phpmailer/phpmailer": "^6.0"
    },
    "config": {
        "platform": {
            "ext-mongo": "1.6.16"
        }
    }
}
```

Along with a vendor folder with all the dependancies in it. 
Then you can `require 'vendor/autoload.php';` to grab your dependancies.


#### Resources

- https://www.slimframework.com/
- https://github.com/FaaPz/Slim-PDO
- https://github.com/delight-im/PHP-Auth
- https://github.com/slimphp/PHP-View
- https://www.google.com/recaptcha/admin#site/339394587?setup
- https://www.google.com/recaptcha/admin#list
- https://code.tutsplus.com/tutorials/an-in-depth-guide-to-mod_rewrite-for-apache--net-6708



