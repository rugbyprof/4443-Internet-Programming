<?php
$settings = include('settings.php');
error_reporting($settings['error_reporting']);
date_default_timezone_set($settings['time_zone']);

// Include dependencies
use Slim\Views\PhpRenderer;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';
require './mongo_helper.php';
require 'debug.php';

$mail = new PHPMailer(true);

$app = new \Slim\App($settings['slim']);

// Get a reference to the slim container so we can add to it.
$container = $app->getContainer();

// Add a view renderer, so we can send back whole views (pages)
// that we build dynamically
$container['view'] = function ($container) {
    // The parameter is the folder containing your views
    return new \Slim\Views\PhpRenderer('./views/');
};

$container['pdo'] = function ($container) {
    global $settings;
    $dsn = 'mysql:host='.$settings['mysql']['host'].';dbname='.$settings['mysql']['dbname'].';charset=utf8';
    $usr = $settings['mysql']['user'];
    $pwd = $settings['mysql']['pass'];
    
    $pdo = new \Slim\PDO\Database($dsn, $usr, $pwd);
    return $pdo;
};


// Now we register a "class" that will handle putting together our views.
// This gets added to the slim "container" as well.
// "ViewController" = name of our class to handle views
// "view" = key that we assigned our view 'renderer' to above
$container['ViewController'] = function ($c) {
    $view = $c->get("view"); // This gets a copy of the renderer we did above
                             // And sends it to our class to use when rendering pages.
    $pdo = $c->get("pdo");
    return new ViewController($view,$pdo);
};

// Add mongo database connectivity
$container['mongo'] = function ($c) {
    $dbname = $c['settings']['mongo']['dbname'];
    return new mongoHelper($dbname);
};

// Create instance of the authentication class
$db = new \PDO("mysql:host={$settings['mysql']['host']};dbname={$settings['mysql']['dbname']};charset=utf8", 
                $settings['mysql']['user'], $settings['mysql']['pass']);
$auth = new \Delight\Auth\Auth($db);

/****************************************************************************************************
 * ROUTES
 ****************************************************************************************************/

// GET /////////////////////////////////////////////////////////////////////////////////////
$app->get("/", "base");
$app->get("/example", "example_handler");
$app->get("/login", \ViewController::class . ":login_view");
$app->get("/email", \ViewController::class . ":email_view");
$app->get("/upload_file", \ViewController::class . ":file_upload_view");
$app->get('/home', \ViewController::class . ":home_view");
$app->get('/profile_page[/{id}]', \ViewController::class . ":profile_view");
$app->get("/register", \ViewController::class . ":register_view");
$app->get("/ufo", \ViewController::class . ":ufo_view");
$app->get("/ufos", "get_ufos");
$app->get("/confirm_email",  \ViewController::class . ":confirm_email");
$app->get("/logout", "logout_user");

// POST /////////////////////////////////////////////////////////////////////////////////////
$app->post("/register", "register_user");
$app->post("/example", "example_handler");
$app->post("/email", "send_email");
$app->post("/upload", "uploadImage");
$app->post("/login", "login_user");


$app->run();

/****************************************************************************************************
 * CONTROLLERS
 ****************************************************************************************************/

/**
 * @Description: Shows all routes
 * @Example: curl -X GET https://griffincomplaints.xyz
 */
function base($request, $response, $args)
{
    global $app;
    $base_url = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

    $routes = $app->getContainer()->get('router')->getRoutes();
    $route_list = [];

    foreach ($routes as $key => $route) {
        $method = $route->getMethods();
        $pattern = $route->getPattern();
        $pattern = substr($pattern, 1);
        $route_list[$method[0]][] = $base_url . $pattern;

    }
    return json_response($response, 200, $route_list);
}

/**
 * @Description: Builds the views to return to user
 * @Example: 
 */
class ViewController
{
    protected $view;

    /**
     * @Params:
     *     $view (\Slim\Views\PhpRenderer): instance of slim view renderer
     */
    public function __construct(\Slim\Views\PhpRenderer $view,$pdo)
    {
        $this->pdo = $pdo;
        $this->view = $view;

        $this->page_data = [];
        $this->page_data['menu_array'] = $this->get_navigation();

        $this->page_data['page_parts'] = [
            'header'=>'header.php',
            'navigation'=>'navigation.php',
            'core_scripts'=>'core_scripts.php',
            'footer'=>'footer.php'
        ];
    }

    public function get_page_parts(){
        return $this->page_data['page_parts'];
    }

    private function get_navigation(){
        $menu_array = [];
        $menus = $this->pdo->select()
        ->from('menu_items');

        $stmt = $menus->execute();
        while($data = $stmt->fetch()){
            if(!array_key_exists($data['mid'],$menu_array)){
                $menu_array[$data['mid']] = [];
            }
            $menu_array[$data['mid']][] = $data;
        }

        //debug (print_r($menu_array,true), date('Y-m-d H:i:s').": navigation ", "./logs/output.log");
        return $menu_array;
    }
    
    /**
     * @Params:
     *     $request (
     *     $response, 
     *     $args
     */
    public function home_view($request, $response, $args)
    {
        // connect the "view" to any data needed and return it as a response
        $this->page_data['args'] = $args;
        return $this->view->render($response, "home.php", $this->page_data);
    }

    /**
     * @Params:
     *     $request (
     *     $response,
     *     $args
     */
    public function ufo_view($request, $response, $args)
    {
        debug ("", date('Y-m-d H:i:s').": ufo_view ", "./logs/output.log");
        // $ufo_query = $this->pdo->select()
        // ->from('ufo_sightings')
        // ->limit(1000);

        // $ufo_array = [];

        // $stmt = $ufo_query->execute();
        // while($data = $stmt->fetch()){
        //     $filter = [];
        //     $filter['id'] = $data['id'];
        //     $filter['latitude'] = $data['latitude'];
        //     $filter['longitude'] = $data['longitude'];
        //     $ufo_array[] = $filter;
        // }

        // debug (print_r($ufo_array,true), date('Y-m-d H:i:s').": ufos ", "./logs/output.log");
        $this->page_data['args'] = $args;
        return $this->view->render($response, "ufo.php", $this->page_data);
    }

    /**
     * @Description:
     *     returns a login screen view
     */
    public function login_view($request, $response, $args)
    {
        $this->page_data['args'] = $args;
        return $this->view->render($response, "login.php",$this->page_data);
    }

    /**
     * @Description:
     *     returns an email view
     */
    public function email_view($request, $response, $args)
    {
        // $allPostPutVars = $request->getParsedBody();
        // $data = print_r($allPostPutVars,true);
        $this->page_data['args'] = $args;
        return $this->view->render($response, "email.php",$this->page_data);
    }

    /**
     * @Description:
     *     returns a view response to registration
     */
    public function register_view($request, $response, $args)
    {
        // $vars = $request->getParsedBody();
        // $data = print_r($allPostPutVars,true);
        $this->page_data['args'] = $args;
        return $this->view->render($response, "register.php",$this->page_data);
    }

    /**
     * @Description:
     *     returns a file upload view
     */
    public function file_upload_view($request, $response, $args)
    {
        //$allPostPutVars = $request->getParsedBody();
        $this->page_data["args"] = $request->getParsedBody();
        $data = print_r($allPostPutVars,true);
        return $this->view->render($response, "file_upload.php", $this->page_data);
    }

    public function confirm_email($request, $response, $args){
        global $auth;
    
        $params = $request->getQueryParams();
        debug (print_r($params,true), date('Y-m-d H:i:s').": confirm email params", "./logs/output.log");
    
        if(array_key_exists('token',$params)){
            list($selector,$token) = explode('~',$params['token']);
            $selector = urldecode($selector);
            $token = urldecode($token);
        }else{
            return json_encode(["success"=>false,"error"=>"No selector or token."]);
        }
    
        try {
            $auth->confirmEmail($selector, $token);
        }
        catch (\Delight\Auth\InvalidSelectorTokenPairException $e) {
            // invalid token
            debug ("invalid token ", date('Y-m-d H:i:s').": catch", "./logs/output.log");
        }
        catch (\Delight\Auth\TokenExpiredException $e) {
            // token expired
            debug ("token expired ", date('Y-m-d H:i:s').": catch", "./logs/output.log");
        }
        catch (\Delight\Auth\UserAlreadyExistsException $e) {
            // email address already exists
            debug ("email address already exists ", date('Y-m-d H:i:s').": catch", "./logs/output.log");               
        }
        catch (\Delight\Auth\TooManyRequestsException $e) {
            // too many requests
            debug ("too many requests ", date('Y-m-d H:i:s').": catch", "./logs/output.log"); 
        }
        return $this->view->render($response, "login.php", $this->page_data);
    }

}

/**
 * @Description:
 *     logs in a user
 */
function logout_user($request, $response, $args)
{
    global $auth;
    global $app;
    $data = $request->getParsedBody();
    debug (print_r($data,true), date('Y-m-d H:i:s').": login ", "./logs/output.log");

    $email = $auth->getEmail();
    if ($auth->isLoggedIn()) {
        $auth->logOut();
        debug (print_r($_SESSION,true), date('Y-m-d H:i:s').": logout session ", "./logs/output.log");
        return json_encode(['success'=>true,'status'=>"logged out"]);
    }
    else {
        return json_encode(['success'=>false,'status'=>"not logged in"]);
    }


}

/**
 * @Description:
 *     logs in a user
 */
function login_user($request, $response, $args)
{
    global $auth;
    global $app;
    $data = $request->getParsedBody();
    debug (print_r($data,true), date('Y-m-d H:i:s').": login ", "./logs/output.log");

    try {
        $auth->login($data['email'], $data['password']);
        if ($auth->isLoggedIn()) {
            debug (print_r($_SESSION,true), date('Y-m-d H:i:s').": login session ", "./logs/output.log");
            return json_response($response, 200, ['success'=>true,'status'=>"logged in"]);
        }
    }
    catch (\Delight\Auth\InvalidEmailException $e) {
        // wrong email address
        return json_encode(['success'=>false,'status'=>"wrong email"]);
    }
    catch (\Delight\Auth\InvalidPasswordException $e) {
        // wrong password
        return json_encode(['success'=>false,'status'=>"wrong password"]);
    }
    catch (\Delight\Auth\EmailNotVerifiedException $e) {
        // email not verified
        return json_encode(['success'=>false,'status'=>"email not verified"]);
    }
    catch (\Delight\Auth\TooManyRequestsException $e) {
        // too many requests
        return json_encode(['success'=>false,'status'=>"too many requests"]);
    }
    
}

/**
 * @Description:
 *     Registers a new user
 */
function register_user($request, $response, $args)
{
    global $auth;
    global $app;
    $data = $request->getParsedBody();
    debug (print_r($data,true), date('Y-m-d H:i:s').": email ", "./logs/output.log");

    debug (print_r($data,true), date('Y-m-d H:i:s').": email ", "./logs/output.log");
    try {
        $userId = $auth->register($data['email'], $data['pwd'], $data['username'], function ($selector, $token) {
        
            debug (print_r(['selector'=>$selector,'token'=>$token],true), date('Y-m-d H:i:s').": register request ", "./logs/output.log");

        });
    
        // we have signed up a new user with the ID `$userId`
        debug ($userId , date('Y-m-d H:i:s').": userid ", "./logs/output.log");
        email_new_user($data,$userId);
        
    }
    catch (\Delight\Auth\InvalidEmailException $e) {
        // invalid email address
        debug ("invalid email", date('Y-m-d H:i:s').": catch ", "./logs/output.log");
    }
    catch (\Delight\Auth\InvalidPasswordException $e) {
        // invalid password
        debug ("invalid password ", date('Y-m-d H:i:s').": catch", "./logs/output.log");
    }
    catch (\Delight\Auth\UserAlreadyExistsException $e) {
        // user already exists
        debug ("user exists ", date('Y-m-d H:i:s').": catch", "./logs/output.log");
    }
    catch (\Delight\Auth\TooManyRequestsException $e) {
        // too many requests
        debug ("too many requests", date('Y-m-d H:i:s').": catch ", "./logs/output.log");
    }
}

/**
 * @Params:
 *     $request (
 *     $response,
 *     $args
 */
function get_ufos($request, $response, $args)
{
    //https://developers.google.com/maps/documentation/javascript/examples/layer-heatmap
    global $app;
    $c = $app->getContainer();
    $pdo = $c->get("pdo");
    $params = $request->getQueryParams();

    if(!array_key_exists('number',$params)){
        $params['number'] = 1000;
    }

    if(!array_key_exists('offset',$params)){
        $params['offset'] = 0;
    }

    $ufo_query = $pdo->select()
    ->from('ufo_sightings')
    ->orderBy('rand()');
    //->limit($params['number'],$params['offset']); //not working!!!

    $data = [];

    $stmt = $ufo_query->execute();
    $count = 0;     //implement my own pagination
    $offset = 0;
    while($row = $stmt->fetch()){
        if($offset < $params['offset']){
            $offset++;
            continue;
        }
        $filter = [];
        $filter['id'] = $row['id'];
        $filter['latitude'] = $row['latitude'];
        $filter['longitude'] = $row['longitude'];
        $filter['shape'] = $row['shape'];
        $data[] = $filter;
        $count++;
        if($count >= $params['number']){
            break;
        }
    }

    // debug (print_r($data,true), date('Y-m-d H:i:s').": ufos ", "./logs/output.log");
    return json_response($response, 200, $data);
}

/**
 * @Description:
 *     Email a new user a link to confirm email address
 *     Needs to not use "hard coded" values, but in a hurry right now.
 */
function email_new_user($data,$userId){
    global $settings;
    global $mail;
    global $app;
    $c = $app->getContainer();
    $pdo = $c->get("pdo");

    $user_query = $pdo->select()
    ->from('users_confirmations')
    ->where('user_id','=',$userId);

    $stmt = $user_query->execute();
    $row = $stmt->fetch();

    $selector = urlencode($row['selector']);
    $token = urlencode($row['token']);

    try {
        //Server settings
        $mail->IsSMTP();
        $mail->SMTPDebug = 0;                                 // Enable verbose debug output
        $mail->SMTPAuth = true; // authentication enabled
        $mail->Host = $settings['mail']['host'];
        $mail->Port = $settings['mail']['port'];
        $mail->SMTPSecure = $settings['mail']['secure'];
        $mail->Username = $settings['mail']['username'];
        $mail->Password = $settings['mail']['password'];
        
        //Recipients
        $mail->setFrom($settings['mail']['from']);
        $mail->addAddress($data['email']);     // Add a recipient
    
        //Content  
        $mail->IsHTML(true);
    
        //$mail->Subject = 'This is a test';
        $mail->Subject = $data['subject'];
        //$mail->Body    = 'This is the HTML message body <b>in bold!</b>';
        $mail->Body    = "Hello!!,<br><br> Please click the link to confirm your email
        address. <a href='https://wtfhw.us/confirm_email?token={$selector}~{$token}'>https://wtfhw.us/confirm_email?token={$selector}~{$token}</a><br><br> Thanks";
        $mail->AltBody = "Hello!!,\n\n Please click the link to confirm your email
        address. <a href='https://wtfhw.us/confirm_email?token={$selector}~{$token}'>https://wtfhw.us/confirm_email?token={$selector}~{$token}</a><\n\n Thanks";
    
        $mail->send();
        echo 'Message has been sent';
    } catch (Exception $e) {
        echo 'Message could not be sent.';
        echo 'Mailer Error: ' . $mail->ErrorInfo;
    }
}



/**
 * @Params:
 *     $request (object): request type
 *     $response (object): response type
 *     $args (object): get args
 */
function example_handler($request, $response, $args)
{
    debug (print_r($request->getParsedBody(),true), date('Y-m-d H:i:s').": request ", "./logs/output.log");
    if($request->isGet()){
        $data['type'] = 'Get';
        $data['qparams'] = $request->getQueryParams();
        $data['params'] = $request->getParams();
    }else if($request->isPost()){
        $data['type'] = 'Post';
        $data['qparams'] = $request->getQueryParams();
        $data['params'] = $request->getParsedBody();
    }

    return json_response($response, 200, $data);
}

/**
 * @Description:
 *     Uses phpMailer to build and send an email based on requesting form
 */
function send_email($request, $response, $args)
{
    $data = $request->getParsedBody();
    require('./scripts/mailer.php');
    return $data;
}

function json_response(&$response, $status, $data)
{
    return $response->withStatus($status)
        ->withHeader('Content-Type', 'application/json')
        ->write(json_encode($data));
}

/**
 * Upload image to waldo site
 *
 * @param
 *      $request (Request) posted values n such
 *      $response (Response) object
 *      $args (array) get arguments
 * @return
 */
function uploadImage($request, $response, $args)
{

    $files = $request->getUploadedFiles();

    debug (print_r($files,true), date('Y-m-d H:i:s').": Files ", "./logs/output.log");

    $uploaded_names = [];
    foreach ($files['files'] as $newfile) {
        debug ($newfile, date('Y-m-d H:i:s').": newfile ", "./logs/output.log");
        if ($newfile->getError() === UPLOAD_ERR_OK) {
            debug ($newfile, date('Y-m-d H:i:s').": name ", "./logs/output.log");
            $uploaded_names[] = moveUploadedFile('./file_uploads', $newfile);
        }
    }
    return json_response($response, 200, ['success' => true, 'filenames' => $uploaded_names]);
}

/**
 * Moves the uploaded file to the upload directory and assigns it a unique name
 * to avoid overwriting an existing uploaded file.
 *
 * @param string $directory directory to which the file is moved
 * @param UploadedFile $uploaded file uploaded file to move
 * @return string filename of moved file
 */
function moveUploadedFile(string $directory, Slim\Http\UploadedFile $uploadedFile)
{
    $extension = pathinfo($uploadedFile->getClientFilename(), PATHINFO_EXTENSION);
    $basename = bin2hex(random_bytes(8)); // see http://php.net/manual/en/function.random-bytes.php
    $filename = sprintf('%s.%0.8s', $basename, $extension);

    $uploadedFile->moveTo($directory . DIRECTORY_SEPARATOR . $filename);

    return $filename;
}


/****************************************************************************************************
 * MODELS
 ****************************************************************************************************/
