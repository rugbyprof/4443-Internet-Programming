<?php
// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function


//Load composer's autoloader
//require 'vendor/autoload.php';

$mail = new PHPMailer(true);                              // Passing `true` enables exceptions
$log->error(print_r($data,true));
try {
    //Server settings
    $mail->IsSMTP();
    $mail->SMTPDebug = 0;                                 // Enable verbose debug output
    $mail->SMTPAuth = true; // authentication enabled
    $mail->Host = "smtp.gmail.com";
    $mail->Port = 587; // or 587
    $mail->SMTPSecure = 'tls';
    $mail->Username = "wtfhw.us@gmail.com";
    $mail->Password = "horseblanketdonkey";
    
    //Recipients
    $mail->setFrom('wtfhw.us@gmail.com', 'Donot Reply');
    $mail->addAddress('terry.griffin@mwsu.edu', 'Terry Griffin');     // Add a recipient
    $mail->addAddress($data['email']);     // Add a recipient
    //$mail->addAddress('ellen@example.com');               // Name is optional
    //$mail->addReplyTo('info@example.com', 'Information');
    //$mail->addCC('cc@example.com');
    //$mail->addBCC('bcc@example.com');

    //Attachments
    //$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
    //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

    //Content  
    $mail->IsHTML(true);

    //$mail->Subject = 'This is a test';
    $mail->Subject = $data['subject'];
    //$mail->Body    = 'This is the HTML message body <b>in bold!</b>';
    $mail->Body    = $data['message'];
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo 'Message could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
}